This module is not finished.

So far it's save to use in:
- Product page
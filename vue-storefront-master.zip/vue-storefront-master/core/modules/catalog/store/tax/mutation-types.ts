export const SN_TAX = 'tax'
export const TAX_UPDATE_RULES = SN_TAX + '/UPDATE_RULES'

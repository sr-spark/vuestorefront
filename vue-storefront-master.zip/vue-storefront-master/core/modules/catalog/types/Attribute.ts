export default interface Attribute {
  attribute_code?: string,
  attribute_id?: number | string
}

export const SN_REVIEW = 'review'
export const REVIEW_UPD_REVIEWS = SN_REVIEW + '/UPD_REVIEWS'

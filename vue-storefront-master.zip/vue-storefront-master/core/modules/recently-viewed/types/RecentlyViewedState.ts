export default interface RecentlyViewedState {
  items: any[]
}

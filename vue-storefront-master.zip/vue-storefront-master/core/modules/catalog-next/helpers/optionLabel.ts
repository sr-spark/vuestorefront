import { optionLabel } from '@vue-storefront/core/modules/catalog/helpers/optionLabel'

// TODO in future move old helper here, add tests and refactor
export { optionLabel }

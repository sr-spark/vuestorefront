import CartTotalSegmentsItem from './CartTotalSegmentsItem'
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export default interface CartTotalSegments extends Array<CartTotalSegmentsItem>{}

export default interface ShippingState {
  methods: any[]
}

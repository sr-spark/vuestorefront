export interface NewsletterState {
  isSubscribed: boolean | null,
  email: string | null
}

export default interface CmsPageState {
  items: any[],
  current: any
}
